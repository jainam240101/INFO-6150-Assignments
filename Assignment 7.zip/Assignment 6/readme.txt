# Website on Jordons Shopping Centre

This website is a Jordons fan-page. People can look and explore the history of Jordons, learn from the words of wisdom of 7-time world champion Micheal Jordon, and also have a look at the most famous Jordons in the world.

# Instructions

1. Install and open VS_CODE and download Live Server and Watch SASS Extension.
2. Import the project and run main.html
2. Import the project and run main.html
3. Open main.html on new tab on chrome or any other browser.
 

# Tags used

1. header --> header tag is used to add a header to the webpage.
2. footer --> footer tag is used to add a footer to the webpage.
3. audio --> Is used to embed audio in the webpage.
4. nav --> Is used for making navigation tags
5. mark --> Highlights the text inside the tag.
6. section --> Divides into different sections.
7. wbr --> Removes a break line from text.